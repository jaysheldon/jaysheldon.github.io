# face-api.js-for-beginners


https://hpssjellis.github.io/face-api.js-for-beginners/



Original github by V. Mueller at  
at https://github.com/justadudewhohacks/face-api.js










